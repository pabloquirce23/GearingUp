$(document).ready(function () {
  $('#all_characters').DataTable();
});
