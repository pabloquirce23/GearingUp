<?php
require_once('header.php');
?>
      <section id="hero-section-blog">
        <div class="hero-bg-img">
          <div class="hero-contents">
            <h1>quiz</h1>
          </div>
        </div>
      </section>

      <section id="quiz-section">
        <div id="uquiz_embed" data-quiz-id="eEGlr3" data-width="100%"></div>
        <script src="https://uquiz.com/embed.js"></script>
      </section>
<?php
require_once('footer.php');
?>
